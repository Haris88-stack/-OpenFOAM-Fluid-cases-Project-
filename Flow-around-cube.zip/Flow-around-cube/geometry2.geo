// Gmsh project created on Mon Apr 13 09:46:47 2026
SetFactory("OpenCASCADE");
//+
Point(1) = {-1, 0.5, 0, 1.0};
//+
Point(2) = {1, 0.5, 0, 1.0};
//+
Point(3) = {-1, -0.5, 0, 1.0};
//+
Point(4) = {1, -0.5, 0, 1.0};
//+
Rectangle(1) = {-0.5, -0.25, 0, 0.5, 0.5, 0};
//+
Line(5) = {1, 2};
//+
Line(6) = {2, 4};
//+
Line(7) = {4, 3};
//+
Line(8) = {3, 1};
//+
Curve Loop(2) = {5, 6, 7, 8};
//+
Plane Surface(2) = {2};
//+
BooleanDifference{ Surface{2}; Delete; }{ Surface{1}; Delete; }
//+
Extrude {0, 0, 0.2} {
  Surface{2}; Layers {1}; Recombine;
}
//+
Physical Surface("inlet", 25) = {4};
//+
Physical Surface("outlet", 26) = {5};
//+
Physical Surface("walls", 27) = {3, 8, 7, 9, 10, 6};
//+
Physical Surface("frontAndBack", 28) = {2, 11};
//+
Physical Volume(29) = {1};
