// Gmsh project created on Thu Apr  9 11:59:28 2026
SetFactory("OpenCASCADE");
//+
Point(1) = {-1, 0.5, 0, 1.0};
//+
Point(2) = {1, 0.5, 0, 1.0};
//+
Point(3) = {-1, 0, 0, 1.0};
//+
Point(4) = {1, -0, 0, 1.0};
//+
Line(1) = {1, 2};
//+
Line(2) = {2, 4};
//+
Line(3) = {4, 3};
//+
Line(4) = {3, 1};
//+
Circle(5) = {-0.5, 0.25, 0, 0.1, 0, 2*Pi};

//+
Curve Loop(1) = {1, 2, 3, 4};
//+
Plane Surface(1) = {1};
//+
Curve Loop(2) = {5};
//+
Plane Surface(2) = {2};
//+
BooleanDifference{ Surface{1}; Delete; }{ Surface{2}; Delete; }
//+
Extrude {0, 0, 0.1} {
  Surface{1}; Layers {1}; Recombine;
}
//+
Physical Surface("inlet", 20) = {3};
//+
Physical Surface("outlet", 21) = {4};
//+
Physical Surface("walls", 22) = {2, 6, 5};
//+
Physical Surface("frontAndBack", 23) = {7, 1};
//+
Physical Volume(24) = {1};
